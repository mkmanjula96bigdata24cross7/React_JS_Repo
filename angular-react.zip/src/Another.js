import React, { Component } from 'react';
import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Form, Card } from 'react-bootstrap'
import DatePicker from "react-datepicker";
import NavBar from "./NavBar";

class Another extends Component {
    constructor(props){
        super(props);
    }
  render() {
    return ( <div className="Another">
    <NavBar/>
      <Card bg="warning" border="light" style={{
                    width: '75rem',
                    marginTop: "70px"
                }}>
                    <Card.Body >
                        <Card.Header >Welcome</Card.Header>
                        <Form>

                            <Row>
                                <Col>
                                    <Form.Group controlId="formGroupType">
                                        <Form.Label>Enter Type </Form.Label>
                                        <Form.Control as="select" placeholder="Enter Type">
                                            <option>Value Stream PQVC</option>
                                            <option>Plant PQVC</option>
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group controlId="formGroupFacility">
                                        <Form.Label>Facility</Form.Label>
                                        <Form.Control as="select" placeholder="Facility">
                                            <option>Planta 1</option>
                                            <option>Planta 2</option>
                                            <option>Planta 3</option>
                                            <option>Planta 4</option>
                                            <option>Planta 5</option>
                                            <option>Planta 4B - Harier</option>
                                            <option>Planta 3B, Mexico</option>
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group controlId="formGroupVStream">
                                        <Form.Label>Value Stream</Form.Label>
                                        <Form.Control as="select" placeholder="Value Stream">
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group controlId="formGroupDate">
                                        <Form.Label>Date</Form.Label>
                                        <DatePicker 
                                            // selected={this.state.startDate}
                                            // onChange={this.handleChange}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>



                        </Form>
                        <Button variant="dark">Proceed</Button>
                    </Card.Body>
                </Card>
                <Card bg="warning" border="light" style={{
                    width: '75rem',
                    marginTop: "70px"
                }}>
                    <Card.Body >
                        <Card.Header >Welcome</Card.Header>
                        <Form>

                            <Row>
                                <Col>
                                    <Form.Group controlId="formGroupType">
                                        <Form.Label>Enter Type </Form.Label>
                                        <Form.Control as="select" placeholder="Enter Type">
                                            <option>Value Stream PQVC</option>
                                            <option>Plant PQVC</option>
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group controlId="formGroupFacility">
                                        <Form.Label>Facility</Form.Label>
                                        <Form.Control as="select" placeholder="Facility">
                                            <option>Planta 1</option>
                                            <option>Planta 2</option>
                                            <option>Planta 3</option>
                                            <option>Planta 4</option>
                                            <option>Planta 5</option>
                                            <option>Planta 4B - Harier</option>
                                            <option>Planta 3B, Mexico</option>
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group controlId="formGroupVStream">
                                        <Form.Label>Value Stream</Form.Label>
                                        <Form.Control as="select" placeholder="Value Stream">
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col>
                                    <Form.Group controlId="formGroupDate">
                                        <Form.Label>Date</Form.Label>
                                        <DatePicker 
                                            // selected={this.state.startDate}
                                            // onChange={this.handleChange}
                                        />
                                    </Form.Group>
                                </Col>
                            </Row>



                        </Form>
                        <Button variant="dark">Proceed</Button>
                    </Card.Body>
                </Card>
      </div>
    );
  }
}

export default Another;
