import React, { Component } from 'react';

import './App.css';
import Home from './Home'
import NavBar from "./NavBar";

import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Form } from 'react-bootstrap'
class App extends Component {



  render() {
    return (
      <div>
        <NavBar/>
      
      <div className="App">
      
        <header className="App-header">
         
          {/* <h2>  Welcome</h2> */}
          {/* <input
            type="file"
            onChange={this.handleFiles}
            accept=".csv"
          /> */}
       
    
  
          <Home />
          
         
        </header>
      </div>
      </div>
    );
  }
}

  export default App;