import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { AvForm, AvField,AvGroup } from 'availity-reactstrap-validation';
import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Input, FormGroup, Form, Label, Card, CardBody, CardHeader } from 'reactstrap'
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
// import Card from 'reactstrap/Card'
// import DatePicker from 'react-bootstrap-date-picker'
import DatePicker from "react-datepicker";
// import 'react-16-bootstrap-date-picker'
// var DatePicker = require("react-bootstrap-date-picker");
import PropTypes from 'prop-types';
import "react-datepicker/dist/react-datepicker.css";
import NavBar from "./NavBar";
class Cost extends Component {
    constructor(props) {
        super(props);
        this.state = {


            rework_time: '',
            rs_cost: '',
            

        }
        this.Validation = this.Validation.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    componentDidMount() {

    }
    static contextTypes = {
        router: PropTypes.object
      }
    Validation(event,values){
        this.context.router.history.push("/quality");
    }
    fieldValidate(value){
        console.log(value)
        if(value>0)
        return true;
        else
        return false;
    }
    onChange(e){
        this.setState({[e.target.value]:e.target.value});
    }




    render() {
        return (
            <div>
                <NavBar/>
            <div style={{marginLeft:"20px"}}>

                <Card style={{
                    width: '75rem',
                    marginTop: "70px"
                }}>
                    <CardHeader body inverse style={{ backgroundColor: '#FAB914' }}><b>People</b></CardHeader>
                    <CardBody >

                        <AvForm onValidSubmit={this.Validation}>

                            <Row>
                                <Col>
                                <Row>

                                    <Col>
                                        <AvGroup>
                                            <Label for="rework_time"><b>Rework time (minutes)</b></Label>
                                            <AvField
                                                type="number"
                                                name="rework_time"
                                                id="rework_time"
                                                placeholder="Enter Rework time (minutes)"
                                                value={this.state.rework_time}
                                                onChange={this.onChange}
                                                required
                                                
                                            />
                                        </AvGroup>
                                    </Col>
                                   
                                </Row>
                                <Row>
                                <Col>
                                        <AvGroup>
                                            <Label for="rs_cost"><b>Rejection & Scrap Cost in Dollar($)</b></Label>
                                            <AvField
                                                type="number"
                                                name="rs_cost"
                                                id="rs_cost"
                                                placeholder="Enter Rejection & Scrap Cost in Dollar($)"
                                                value={this.state.rs_cost}
                                                onChange={this.onChange}
                                                // validate={this.fieldValidate}
                                                required
                                            />
                                        </AvGroup>
                                    </Col>
                                </Row>
                                </Col>

                            </Row>
                            <div>  


<Button color="primary" type='submit'
    >
    Save

</Button>
</div>



                        </AvForm>
                        <br/>
                      

                    </CardBody>
                </Card>

               </div>
               </div>

        );
    }
}

export default Cost;
