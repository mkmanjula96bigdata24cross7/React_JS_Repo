import React, { Component } from 'react';
import logo from './logo.svg';
import PropTypes from 'prop-types';
import './App.css';
import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Input, FormGroup, Form, Label, Card, CardBody, CardHeader } from 'reactstrap'
import { AvForm, AvInput,AvField,AvGroup} from 'availity-reactstrap-validation';
// import Card from 'reactstrap/Card'
// import DatePicker from 'react-bootstrap-date-picker'
import DatePicker from "react-datepicker";
// import 'react-16-bootstrap-date-picker'
// var DatePicker = require("react-bootstrap-date-picker");
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import "react-datepicker/dist/react-datepicker.css";
import NavBar from "./NavBar";
class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {


            date: '',
            shift: ''

        }
        this.Validation = this.Validation.bind(this);
    }
    static contextTypes = {
        router: PropTypes.object
      }

    componentDidMount() {

    }
    Validation(e){
        e.preventDefault();
        this.context.router.history.push("/people");
    }


    render() {
        return (
            <div>
            <NavBar/>
            <div style={{marginLeft:"20px"}}>
            
           
             

                <Card style={{
                    width: '75rem',
                    marginTop: "70px"
                }}>
                    <CardHeader body inverse style={{ backgroundColor: '#FAB914' }}><b>Welcome to OHT!!</b></CardHeader>
                    <CardBody >
                    



                        <AvForm onValidSubmit={this.Validation}>

                            <Row>

                                <Col>
                                    <AvGroup controlId="formGroupDate">
                                        <Label for="date"><b>Date</b></Label>
                                        {/* <DatePicker 
                                            // selected={this.state.startDate}
                                            // onChange={this.handleChange}
                                        /> */}
                                        <AvField
                                            type="date"
                                            name="date"
                                            id="date"
                                            placeholder="date placeholder"
                                            errorMessage="Field Required"
                                            required
                                        />
                                    </AvGroup>
                                </Col>
                                <Col>
                                    {/* <FormGroup controlId="formGroupFacility">
                                        <Label>Facility</Label>
                                        <Input as="select" placeholder="Facility">
                                            
                                        </Input>
                                    </FormGroup> */}
                                    <AvGroup>
                                        <Label for="shift"><b>Shift</b></Label>
                                        <AvField type="select" name="shift" id="shift" placeholder="Select Shift"  errorMessage="Field Required" required>
                                            <option value="" hidden>Select Shift</option>
                                            <option value="Shift 1">Shift 1</option>
                                            <option value="Shift 2">Shift 2</option>
                                            <option value="Shift 3">Shift 3</option>

                                        </AvField>
                                    </AvGroup>
                                </Col>
                            </Row>
                            <br/>
                            <br/>

                           <Button color="primary"type="submit">Proceed</Button>

                        </AvForm>
                         
                   
                        
                    </CardBody>
                </Card>

            </div>
            </div>

        );
    }
}

export default Home;
