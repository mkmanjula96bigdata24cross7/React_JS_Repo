import React, { Component } from 'react';
import {
  Container, Col, Form,
  FormGroup, Label, Input,Row,
  Button,Card,CardBody,CardHeader,CardTitle
} from 'reactstrap';
import Routing from './Routing';
import { AvForm, AvInput,AvField,AvGroup} from 'availity-reactstrap-validation';

import { Route, Link, BrowserRouter as Router } from 'react-router-dom';

// import { CardTitle } from 'material-ui';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {


           isValid:false,

        }
        this.Validate = this.Validate.bind(this);

    }
  Validate(event,value){
    // var value=Document.getElementById("uname").value; 
   console.log(value)
    if(value.uname=="oht")
  //  {  this.state.isValid=true;
  {
    this.setState(prevState => ({ isValid: true }));
       return true;
   }
   else{
       alert("Enter a valid Username!!")
       return false;
   }
  }

  render() {
    return (
        <div >
         
        <Card style={{
            width: '20rem',
            
            display: "block",
    marginLeft: "auto",
    marginRight: "auto",
             justifyContent: "center" 
            
        }}>
            <CardHeader body inverse style={{ backgroundColor: '#FAB914' }}><b>Login</b></CardHeader>
            {/* <CardTitle>Login to Your Account</CardTitle> */}
            <CardBody >
                <br/>
                <br/>
                
        <AvForm className="form" onValidSubmit={this.Validate} >
          <Row>
          <Col>
            <AvGroup>
              <Label><b>Username</b></Label>
              <AvField
                type="name"
                name="uname"
                id="uname"
                placeholder="Enter Username"
              />
            </AvGroup>
          </Col>
          </Row>
          
          <br/>
          <br/>
          
          <div>
          {this.state.isValid? 
          <div>  
         
              <div>
            
            <Route render={({ history }) => (


<Button color="primary" type='submit'
    onClick=   {()=>{history.push('/home')} } >
    Proceed </Button>
)} />
</div>

</div>
 :
 <div>
  


  <Button color="primary" type='submit' >
      Proceed </Button>
  
  
</div>}
</div>
       
        </AvForm>
      </CardBody>
      </Card>
      </div>
    );
  }
}

export default Login;