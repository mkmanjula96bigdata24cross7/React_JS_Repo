import React, { Component } from 'react';
import Submit from './Submit';
import Another from './Another';
import Home from './Home';
import Quality from './Quality';
import App from './App';
import People from './People';
import Velocity from './Velocity';
import Cost from './Cost';
import Login from './Login';
import {Route, Link, BrowserRouter as Router } from 'react-router-dom'
import PropTypes from 'prop-types';
import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Form } from 'react-bootstrap'
// import Login from './Login'
// import Quality from './Quality';
// import Another from './Another';
// import Submit from './Submit'
class NavBar extends Component{
    constructor(props){
        super(props);
        this.logout = this.logout.bind(this);
    }
    static contextTypes = {
        router: PropTypes.object
      }

    componentDidMount() {

    }
     logout(e){
        e.preventDefault();
        this.context.router.history.push("/");
    }

    render(){
        return(<div>


<Navbar bg="dark" variant="dark">
<Navbar.Brand href="#home">FMS</Navbar.Brand>
<Nav className="mr-auto">
  <Nav.Link href="/home">Home</Nav.Link>
  <Nav.Link href="/people">People</Nav.Link>
  <Nav.Link href="/quality">Quality</Nav.Link>
  <Nav.Link href="/velocity">Velocity</Nav.Link>
  <Nav.Link href="/cost">Cost</Nav.Link>
  <Nav.Link href="/other">Report</Nav.Link>
  
</Nav>
{/* <Form inline>
  <FormControl type="text" placeholder="Search" className="mr-sm-2" /> */}
  <Button variant="outline-info" onClick={this.logout}>Logout</Button>
{/* </Form> */}
</Navbar>
</div>

)
}
}
export default NavBar;