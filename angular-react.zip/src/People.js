import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Input, FormGroup, Form, Label, Card, CardBody, CardHeader } from 'reactstrap'
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import { AvForm,AvRadio,AvRadioGroup, AvInput,AvField,AvGroup} from 'availity-reactstrap-validation';
// import Card from 'reactstrap/Card'
// import DatePicker from 'react-bootstrap-date-picker'
import DatePicker from "react-datepicker";
// import 'react-16-bootstrap-date-picker'
// var DatePicker = require("react-bootstrap-date-picker");
import PropTypes from 'prop-types';
import "react-datepicker/dist/react-datepicker.css";
import NavBar from "./NavBar";
class People extends Component {
    constructor(props) {
        super(props);
        this.state = {


            no_of_operators: '',
            no_of_apprentice: '',
            no_of_agency: '',
            injury_free:''

        }
        this.Validation = this.Validation.bind(this);
        this.onChange=this.onChange.bind(this);
    }

    componentDidMount() {

    }
    static contextTypes = {
        router: PropTypes.object
      }
    Validation(event,values){
        this.context.router.history.push("/quality");
    }
    onChange(e){
        console.log(e.target.name);
        console.log(e.target.value);
        this.setState({[e.target.name]:e.target.value});
        console.log(this.state);
        
    }



    render() {
        return (
            <div>
            <NavBar/>
            <div style={{marginLeft:"20px"}}>
               
                <Card style={{
                    width: '75rem',
                    marginTop: "70px"
                }}>
                    <CardHeader body inverse style={{ backgroundColor: '#FAB914' }}><b>People</b></CardHeader>
                    <CardBody >

                        <AvForm onValidSubmit={this.Validation}>

                            <Row>
                                <Col>
                                <Row>

                                    <Col>
                                        <AvGroup>
                                            <Label for="no_of_operators"><b>No of Operators</b></Label>
                                            <AvField
                                                type="number"
                                                name="no_of_operators"
                                                id="no_of_operators"
                                                placeholder="No of Operators"
                                                errorMessage="Field Required"
                                                value={this.state.no_of_operators}
                                                onChange={this.onChange}
                                                required
                                            />
                                        </AvGroup>
                                    </Col>
                                    <Col>
                                        <AvGroup>
                                            <Label for="no_of_apprentice"><b>No of Apprentice</b></Label>
                                            <AvField
                                                type="number"
                                                name="no_of_apprentice"
                                                id="no_of_apprentice"
                                                placeholder="No of Apprentice"
                                                errorMessage="Field Required"
                                                value={this.state.no_of_apprentice}
                                                onChange={this.onChange}
                                                required
                                            />
                                        </AvGroup>
                                    </Col>
                                    <Col>
                                        <AvGroup >
                                            <Label for="no_of_agency"><b>No of Agency</b></Label>
                                            <AvField
                                                type="number"
                                                name="no_of_agency"
                                                id="no_of_agency"
                                                placeholder="No of Agency"
                                                errorMessage="Field Required"
                                                value={this.state.no_of_agency}
                                                onChange={this.onChange}
                                                required
                                            />
                                        </AvGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col>
                                    {/* <b>Is injury free day?</b>
                                    <AvGroup check>
                                        <Label check>
                                            <AvField type="radio" name="injury"  />{' '}
                                            Yes
                                         </Label>
                                    </AvGroup >
                                    <AvGroup check>
                                        <Label check>
                                            <AvField type="radio" name="injury" value="No"  />No
                                         </Label>
                                    </AvGroup> */}
                                    <AvRadioGroup name="injury_free" label="Is injury free day?"
                                    value={this.state.injury_free}
                                    // onChange={this.onChange}
                                    required errorMessage="Pick one!">
          <AvRadio label="Yes" value="Yes" />
          <AvRadio label="No" value="No" />
  
        </AvRadioGroup>
                                    </Col>
                                </Row>
                                </Col>

                            </Row>



                           
                        <br/>
                        <div>  


                            <Button color="primary" type='submit'>
                                Proceed

                            </Button>
                        </div>
                      </AvForm>
                    </CardBody>
                </Card>

               </div>
               </div>

        );
    }
}

export default People;
