// import React, { Component } from 'react';

// // import {Card,CardActionArea,CardMedia,CardContent,CardActions,TextField,FormControl,FormLabel,RadioGroup,FormControlLabel} from 'material-ui'
// import Button from '@material-ui/core/Button';
// import PropTypes from 'prop-types';
// import { withStyles } from '@material-ui/core/styles';
// import Card from '@material-ui/core/Card';
// import CardActionArea from '@material-ui/core/CardActionArea';
// import CardActions from '@material-ui/core/CardActions';
// import CardContent from '@material-ui/core/CardContent';
// import CardMedia from '@material-ui/core/CardMedia';
// import Radio from '@material-ui/core/Radio';
// import RadioGroup from '@material-ui/core/RadioGroup';
// import FormHelperText from '@material-ui/core/FormHelperText';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import FormControl from '@material-ui/core/FormControl';
// import FormLabel from '@material-ui/core/FormLabel';
// import TextField from '@material-ui/core/TextField';
// import Typography from '@material-ui/core/Typography';
// import SaveIcon from '@material-ui/icons/Save';
// import classNames from 'classnames';
// class People extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {


//             no_of_operators: '',
//             no_of_apprentice: '',
//             no_of_agency: ''

//         }
//     }

//     componentDidMount() {

//     }



//     render() {
//         var {classes} =this.props;
//         return (


// <div>

// <Card className={classes.card} >
// <CardActionArea>
//   <CardMedia
//     className={classes.media}
//     image="/static/images/cards/contemplative-reptile.jpg"
//     title="Contemplative Reptile"
//   />
//   <CardContent>
//     <Typography gutterBottom variant="h5" component="h2">
//      People
//     </Typography>
 
//   </CardContent>
// </CardActionArea>
// <CardActions>
//  <form className={classes.container}  noValidate autoComplete="off">
//  <TextField
//           id="outlined-number"
//           label="Number"
//         //   value={this.state.age}
//         //   onChange={this.handleChange('age')}
//           type="number"
//           className={classes.textField}
//           InputLabelProps={{
//             shrink: true,
//           }}
//           margin="normal"
//           variant="outlined"
//         />
//   <TextField
//           id="outlined-number"
//           label="Number"
//         //   value={this.state.age}
//         //   onChange={this.handleChange('age')}
//           type="number"
//           className={classes.textField}
//           InputLabelProps={{
//             shrink: true,
//           }}
//           margin="normal"
//           variant="outlined"
//         />
//     <FormControl component="fieldset" className={classes.formControl}>
//           <FormLabel component="legend">Gender</FormLabel>
//           <RadioGroup
//             aria-label="Gender"
//             name="gender1"
//             // className={classes.group}
//             // value={this.state.value}
//             // onChange={this.handleChange}
//           >
//             <FormControlLabel value="yes" control={<Radio />} label="Yes" />
//             <FormControlLabel value="no" control={<Radio />} label="No" />
           
//             <FormControlLabel
//               value="disabled"
//               disabled
//               control={<Radio />}
//               label="(Disabled option)"
//             />
//           </RadioGroup>
//         </FormControl>
//         <Button variant="contained" size="small" type="submit" className={classes.button}>
//         <SaveIcon className={classNames(classes.leftIcon, classes.iconSmall)} />
//         Save
//       </Button>
//  </form>
// </CardActions>
// </Card>
// </div>)}}

// People.propTypes = {
//     classes: PropTypes.object.isRequired,
//   };
  
//   export default(People);