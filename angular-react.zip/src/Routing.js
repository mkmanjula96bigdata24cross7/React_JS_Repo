import React, { Component } from 'react';
import Submit from './Submit';
import Another from './Another';
import Home from './Home';
import Quality from './Quality';
import App from './App';
import People from './People';
import Velocity from './Velocity';
import Cost from './Cost';
import Login from './Login';
import {Route, Link, BrowserRouter as Router } from 'react-router-dom'

import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Form } from 'react-bootstrap'
// import Login from './Login'
// import Quality from './Quality';
// import Another from './Another';
// import Submit from './Submit'
class Routing extends Component{
    constructor(props){
        super(props);
    }
    render(){
        return(<div>
     
 
    <Router>
            <div>
            {/* <Route  path="/route"component={App}> </Route> */}
            
            <Route  path="/sub" component={Submit} />
            <Route  path="/other" component={Another } />
            <Route  path="/people" component={People}/>
            <Route  path="/quality" component={Quality}/>
            <Route path="/velocity" component={Velocity}/>
            <Route  path="/cost" component={Cost}/>
           
            {/* <Route render={({ history }) => 
            {()=>{history.push('/home')} }}/> */}
            {/* <Route exact path="/" component={Login}/> */}
            <Route exact path="/home" component={Home}/>
            <Route exact path="/" component={Login}/>
            </div>
        </Router>
        </div>

        )
    }
}
export default Routing;