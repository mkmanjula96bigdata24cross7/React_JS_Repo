import React, { Component } from 'react';
import { Button, Row, Col, Nav, Navbar, NavDropdown, FormControl, Form, Card } from 'react-bootstrap'

class Submit extends Component {
    constructor(props){
        super(props);
    }
  
    render() {
    
    return (
        <div className="Submit">
        <h1>Submit page</h1>
     
     
      </div>
    );
  }
}

export default Submit;
