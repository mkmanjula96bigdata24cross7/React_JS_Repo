import React from 'react';
import { ListGroup, ListGroupItem } from 'reactstrap';
import { CardFooter,CardHeader,Card,Collapse,CardBody,Row,Col,Button } from 'reactstrap';
import Form1 from "./velocity_forms/Form1"
import Form2 from "./velocity_forms/Form2"
import Form5 from "./velocity_forms/Form5"
import Form7 from "./velocity_forms/Form7"
import Form9 from "./velocity_forms/Form9"
import NavBar from "./NavBar"
export default class Example extends React.Component {
    constructor(props) {
        super(props);
   
        this.state = { 
            // collapse_1: false,
            // collapse_2:false,
            // collapse_3:false,
            // collapse_4: false,
            // collapse_5:false,
            // collapse_6:false,
            // collapse_7: false,
            // collapse_8:false,
            // collapse_9:false,
            collapse:[false,false,false,false,false,false,false,false,false]
         };
         this.toggle_1 = this.toggle_1.bind(this);
         this.toggle_2 = this.toggle_2.bind(this);
         this.toggle_3 = this.toggle_3.bind(this);
         this.toggle_4 = this.toggle_4.bind(this);
         this.toggle_5 = this.toggle_5.bind(this);
         this.toggle_6 = this.toggle_6.bind(this);
         this.toggle_7 = this.toggle_7.bind(this);
         this.toggle_8 = this.toggle_8.bind(this);
         this.toggle_9 = this.toggle_9.bind(this);
         this.collapseAll=this.collapseAll.bind(this);
         this.expandAll=this.expandAll.bind(this);
      }
    
      toggle_1() {
         
        this.setState(prevState => (prevState.collapse[0]=!prevState.collapse[0]));
      }
      toggle_2() {
        this.setState(prevState => (prevState.collapse[1]=!prevState.collapse[1]));
      }
      toggle_3() {
        this.setState(prevState => (prevState.collapse[2]=!prevState.collapse[2]));
      }
      toggle_4() {
        console.log(this)
      this.setState(prevState => (prevState.collapse[3]=!prevState.collapse[3]));
    }
    toggle_5() {
      this.setState(prevState => (prevState.collapse[4]=!prevState.collapse[4]));
    }
    toggle_6() {
      this.setState(prevState => (prevState.collapse[5]=!prevState.collapse[5]));
    }
    toggle_7() {
        console.log(this)
      this.setState(prevState => (prevState.collapse[6]=!prevState.collapse[6]));
    }
    toggle_8() {
      this.setState(prevState => (prevState.collapse[7]=!prevState.collapse[7]));
    }
    toggle_9() {
      this.setState(prevState => (prevState.collapse[8]=!prevState.collapse[8]));
    }
      collapseAll(){
        var temp=[false,false,false,false,false,false,false,false,false];
        this.setState(prevState => (  
         prevState.collapse=temp
         ));
      }
      expandAll(){
        var temp=[true,true,true,true,true,true,true,true,true];
        this.setState(prevState => (    prevState.collapse=temp
         ));
      }
      Prev = (e) => {
        console.log(e.target.value);
        var i=parseInt(e.target.value);
        this.setState(prevState =>{
          
          prevState.collapse[i]=false;
          prevState.collapse[i-1]=true;
          return prevState;
        });

      }
      Next = (e) => {
      
        console.log(e.target.value);
        var i=parseInt(e.target.value);
        this.setState(prevState =>{
          
          prevState.collapse[i]=false;
          prevState.collapse[i+1]=true;
          return prevState;
        });

      }

  render() {

    return (
    //   <ListGroup>
    //     <ListGroupItem color="success">
        <div>
          <NavBar/>
            <br/>
            <br/>
            <br/>
            
            <Row >
            <Col>
            
            <Button onClick={this.expandAll} variant="primary">Expand All</Button>
            </Col>
            <Col>
            </Col>
            <Button onClick={this.collapseAll} variant="primary">Collapse All</Button>
           
            </Row>
           <br/>
           <br/> 
           <br/>
                         
          <Card>
          <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_1} ><b>Indexing Performance</b></CardHeader>
          <Collapse isOpen={this.state.collapse[0]}>
            <CardBody>
            <Form1 />
            </CardBody>
            <CardFooter> 
            <Row >
            <Col>
            
            </Col>
            <Col>
            </Col>
            <Button value="0" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
            </Collapse>
          </Card>
        {/* //   </ListGroupItem> */}
        {/* //   <ListGroupItem  color="success"> */}
        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_2}><b>Stop Time</b></CardHeader>
        <Collapse isOpen={this.state.collapse[1]}>
          <CardBody>
          <Form2/>
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="1"onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
            <Button value="1" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>
      
        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_3}><b>OHT / TOSNO MPS Status</b></CardHeader>
        <Collapse isOpen={this.state.collapse[2]}>
          <CardBody>
          Anim pariatur cliche reprehenderit,
           enim eiusmod high life accusamus terry richardson ad squid. Nihil
           anim keffiyeh helvetica, craft beer labore wes anderson cred
           nesciunt sapiente ea proident.
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="2" onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
            <Button value="2" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>
       
        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_4}><b>SOL To FOL -Part I</b></CardHeader>
        <Collapse isOpen={this.state.collapse[3]}>
          <CardBody>
          Anim pariatur cliche reprehenderit,
           enim eiusmod high life accusamus terry richardson ad squid. Nihil
           anim keffiyeh helvetica, craft beer labore wes anderson cred
           nesciunt sapiente ea proident.
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="3" onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
            <Button value="3" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>

        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_5}><b>SOL To FOL -Part II</b></CardHeader>
        <Collapse isOpen={this.state.collapse[4]}>
          <CardBody>
          <Form5/>
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="4" onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
            <Button value="4" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>

        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_6}><b>Paint Touch Up</b></CardHeader>
        <Collapse isOpen={this.state.collapse[5]}>
          <CardBody>
          Anim pariatur cliche reprehenderit,
           enim eiusmod high life accusamus terry richardson ad squid. Nihil
           anim keffiyeh helvetica, craft beer labore wes anderson cred
           nesciunt sapiente ea proident.
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="5" onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
            <Button value="5" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>

        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_7}><b>Paint SOL To Paint FOL</b></CardHeader>
        <Collapse isOpen={this.state.collapse[6]}>
          <CardBody>
          <Form7/>
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="6" onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
            <Button value="6" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>

        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_8}><b>Paint FOL To RTS</b></CardHeader>
        <Collapse isOpen={this.state.collapse[7]}>
          <CardBody>
          Anim pariatur cliche reprehenderit,
           enim eiusmod high life accusamus terry richardson ad squid. Nihil
           anim keffiyeh helvetica, craft beer labore wes anderson cred
           nesciunt sapiente ea proident.
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="7" onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
            <Button value="7" onClick={this.Next} variant="primary">Next</Button>
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>

        <Card>
        <CardHeader body inverse style={{ backgroundColor: '#FAB914' }} onClick={this.toggle_9}><b>RTS Shippment</b></CardHeader>
        <Collapse isOpen={this.state.collapse[8]}>
          <CardBody>
          <Form9/>
          </CardBody>
          <CardFooter> 
            <Row >
            <Col>
            <Button value="8" onClick={this.Prev} variant="primary">Previous</Button>
            </Col>
            <Col>
            </Col>
         
           
            </Row>
            </CardFooter>
          </Collapse>
        </Card>
        
        {/* </ListGroupItem>
        <ListGroupItem color="info">Dapibus ac facilisis in</ListGroupItem>
        <ListGroupItem color="warning">Morbi leo risus</ListGroupItem>
        <ListGroupItem color="danger">Porta ac consectetur ac</ListGroupItem>
      </ListGroup> */}
      
      </div>
    );
  }
}