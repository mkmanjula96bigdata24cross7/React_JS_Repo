import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Headerbar from './components/Headerbar'
import MuiThemeProvider from '@material-ui/core/styles/MuiThemeProvider';
import CardContent from "@material-ui/core/CardContent";
import TextField from '@material-ui/core/TextField';
import { createMuiTheme } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import CardHeader from '@material-ui/core/CardHeader';
import Paper from '@material-ui/core/Paper';

let imgUrl = 'images/berlin.jpg'
   
//import Route_path from './Route_path'
const styles = theme =>({
    avatar: {
        backgroundColor: 'black',
      },
      chead: {
        backgroundColor: '#FFC107',
        color: "black",
        fontSize :30,
        fontWeight:'bold'
        
      },
      container: {
        display: 'flex',
        flexWrap: 'wrap',
      },
    card: {
        //maxWidth: 700,
        height:300,
        // marginTop: 50,
        // marginLeft:70,
        // marginRight:70,
        marginLeft: theme.spacing.unit*6,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit*6,
        color: '#Ffab00'
      },
      paper: {
        //minWidth: 275,
        height:300,
        marginLeft: theme.spacing.unit*6,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit*6,
        color: '#Ffab00'
      },
      textField: {
        //   marginTop:50,
        // marginLeft: 90,
        // marginRight: 30,
        marginLeft: theme.spacing.unit*7,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit,
        width: 200,
      },
  root: {
    flexGrow: 20,
    marginTop:1,
   
    
  },
  grow: {
    flexGrow: 10,
    align:'center'
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  formControl: {
   marginTop:-48,
    minWidth: 200,
    marginLeft: 400
    
  },

  
  button: {
    margin: theme.spacing.unit,
    // marginTop:10,
    // minWidth: 150,
   // marginLeft: -230,
    backgroundColor:  'black',
    color:'white',
    hover:'green'
  },
 title:{
    fontSize:17,
    fontWeight:'bold'

 } 
});
//const imgMyimageexample = require('delivery.png');


const theme1 = createMuiTheme({
    palette: {
        primary:{
            main: '#263238'
        },
      secondary: {
          main: '#FFC107'
                }
            },
    
                  
  
          });

          function validate(rework,cost){
            const errors=[]
            if(rework< 0 || cost<0 ){
              //alert.show('negative')
              errors.push("Value field cannot be negative. Please enter positive number!!")
            }
            
            return errors;
          }


//function ButtonAppBar(props) {
 // const { classes } = props;
  //const bull = <span className={classes.bullet}>•</span>;
  class Cost extends React.Component{
    state = {
        rework:'0',
        cost:'0',
        name: 'xyz',
        errors:[],
        labelWidth: 0,
      };
      
      // handleClick(e) {
      //   e.preventDefault();
      // }
      constructor(props) {
        super(props);
        this.handlesubmit=this.handlesubmit.bind(this);
      }
    
      
      handlesubmit(e){
        e.preventDefault();
        const {rework} =this.state;
        const {cost} =this.state;
       
        
        
        const errors = validate(rework,cost);
        if(errors.length > 0){
          this.setState({errors});
          return;
        }
        else{
          let path = '/';
          this.props.history.push(path);
        }
        
      }


       handleCallToRouter = (value) => {
           this.props.history.push(value);
         } 
        handleChange = name => event => {
          this.setState({
            [name]: event.target.value,
          });
        };

  render(){
    const { classes } = this.props;
    const { errors} = this.state;
  return (
    
    <MuiThemeProvider theme={theme1}> 
    <Headerbar> </Headerbar>
      <div>
      <Paper className={classes.paper}>
      <form name='costform' onSubmit={this.handlesubmit}   autoComplete="off">
      <CardHeader className={classes.chead} 
          avatar={
            <Avatar aria-label="Recipe" className={classes.avatar}>
             C
              
            </Avatar>
          }
          classes={{
            title: classes.title,
          }}
          title="Cost Details"
         action={
<Button variant="contained" type ='submit' color='secondary' className={classes.button}>
          Proceed
        </Button>
         }
        />
      <CardContent>
        
        {/* <Typography variant="inherit"  align='center' component="h3">
          Welcome to FABRICATION (Main and Feeder)!!!
        </Typography> */}
        
      </CardContent>
      <div className={classes.container}>
      <TextField
       required
       
        label="Rework Time (minutes)"
        type="number"
        variant="outlined"
        value={this.state.rework}
        onChange={this.handleChange('rework')}
        className={classes.textField}
        InputLabelProps={{
          shrink: true,
        }}
      />

<TextField
       required
       
       label="Rejection and Scrap Cost in Dollars ($)"
       type="number"
       variant="outlined"
       value={this.state.cost}
       onChange={this.handleChange('cost')}
       className={classes.textField}
       InputLabelProps={{
         shrink: true,
       }}
     />
     </div>
      
        </form>
        <div>
        {errors.map(error => (
          <p key={error}>Error: {error}</p>
        ))}
        </div>
    
    
    </Paper>
 
    </div>
   
    </MuiThemeProvider > 
 

  );
}
  }

export default withStyles(styles)(Cost);

