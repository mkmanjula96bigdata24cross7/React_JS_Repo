import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import { Link} from "react-router-dom";
import MuiThemeProvider from '@material-ui/core/styles/MuiThemeProvider';
import Paper from '@material-ui/core/Paper';
import ErrorIcon from '@material-ui/icons/Error';
import CardContent from "@material-ui/core/CardContent";
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import { createMuiTheme } from '@material-ui/core/styles';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Avatar from '@material-ui/core/Avatar';
import CardHeader from '@material-ui/core/CardHeader';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import LinkButton from './LinkButton'

//import Route_path from './Route_path'

function validate(shift){
  const errors=[]
  if(shift.length === 0){
 
    errors.push("Please select Shift Type!!")
  }
  
  return errors;
}


const styles = theme=>({
    avatar: {
        backgroundColor: 'black',
      },
      chead: {
        backgroundColor: '#FFC107',
        color: "black",
        fontSize :30,
        fontWeight:'bold'
        
      },
      card: {
        //minWidth: 275,
        height:300,
        marginLeft: theme.spacing.unit*6,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit*6,
        color: '#Ffab00'
      },
      paper: {
        maxWidth: 400,
        height:400,
        marginLeft: theme.spacing.unit*6,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit*6,
        color: '#Ffab00'
      },
      textField: {
        marginLeft: theme.spacing.unit*7,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit,
        width: 200,
        
      },
  root: {
    flexGrow: 20,
    marginTop:1,
   
    
  },
  grow: {
    flexGrow: 10,
    align:'center'
  },
 
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  
  button: {
    // 
    margin: theme.spacing.unit,

    backgroundColor:  'black',
    color:'white'
  },
 title:{
    fontSize:17,
    fontWeight:'bold'

 } 
});
//const imgMyimageexample = require('delivery.png');


const theme1 = createMuiTheme({
    palette: {
        primary:{
            main: '#263238'
        },
      secondary: {
          main: '#FFC107'
                }
            },
    
                  
  
          });

          const variantIcon = {
           
            error: ErrorIcon,
           
          };

//function ButtonAppBar(props) {
 // const { classes } = props;
  //const bull = <span className={classes.bullet}>•</span>;
  class Home extends React.Component{
    state = {
       date:'',
        shift:'',
        name: '',
        labelWidth: 0,

        errors:[]
      };
      
      // handleClick(e) {
      //   e.preventDefault();
      // }
      
      handleChange = event => {
        this.setState({ [event.target.name]: event.target.value });
      };
       handleCallToRouter = (value) => {
           this.props.history.push(value);
         } 
        constructor(props) {
          super(props);
          this.routeChange = this.routeChange.bind(this);
          this.handlesubmit=this.handlesubmit.bind(this);
        }
      
        handlesubmit(e){
          e.preventDefault();
          const {shift} =this.state;
          
          const errors = validate(shift);
          if(errors.length > 0){
            this.setState({errors});
            return;
          }
          else{
            let path = '/people';
            this.props.history.push(path);
          }
        }

        routeChange() {
          let path = '/people';
          this.props.history.push(path);
        }

  render(){
    const { classes } = this.props;
    const { errors} = this.state;
  return (
    
    <MuiThemeProvider theme={theme1}> 
    
    <div className={classes.root}>
    
    <AppBar position="static" color="secondary">
    
      <Toolbar>
        <IconButton className={classes.menuButton} color="inherit" aria-label="Menu">
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" color="inherit"  className={classes.grow} >
          Facility Monitoring System
        </Typography>
        {/* <Link to="/" style={{ textDecoration: 'none',color:'primary',display: 'block', height: '100%'  }}><Button color="inherit" display='block' >Logout</Button></Link> */}
      
        <LinkButton style={{ textDecoration: 'none',color:'primary',display: 'block', height: '100%'  }}
  to='/'
  onClick={(event) => {
    console.log('custom event here!', event)
  }}
>Logout</LinkButton>
      
      </Toolbar>
      

    </AppBar>
    
    
      <AppBar position="static">
      <Tabs
         value={this.state.value}
         onChange={this.handleChange}
          indicatorColor="primary"
         
          
        >
        <Tab label="Home" value="/home" component={Link} to="/home"/>
          {/*  <Tab label="People" value="/people" component={Link} to="/people" />  */}
          {/* <Tab label="Home" />
          <Tab   label="People"   /> 
          <Tab label="Cost" /> */}
          {/* <Tab label="People" value="/people" component={Link} to="/people" /> 
          <Tab label="Quality" value="/quality" component={Link} to="/quality" /> 

          <Tab label="Cost" value="/cost" component={Link} to="/cost"/> */}
        </Tabs>
       {/* <Tab label="Item Two" value="/login" component={Link} to="/login" />  */}

      </AppBar>
      
    </div>
      
   
    
 
      <div>
      <Paper className={classes.paper}>
      <form name='homeform' onSubmit={this.handlesubmit} autoComplete="off" >
      <CardHeader className={classes.chead} 
          avatar={
            <Avatar aria-label="Rec" className={classes.avatar}>
              W
              
            </Avatar>
          }
          classes={{
            title: classes.title,
          }}
          title="Welcome to Fabrication (Main and Feeder)!!!"
         action={
          <Button type='submit' variant="contained" color='secondary'   className={classes.button}>
          Proceed
        </Button>
         }
        />
      <CardContent>
     

        {/* <Typography variant="inherit"  align='center' component="h3">
          Welcome to FABRICATION (Main and Feeder)!!!
        </Typography> */}
        
      
      {/* <LinkButton>hello</LinkButton> */}
      <div className={classes.container}>
      <TextField
       required
        id="date"
        label="Date"
        type="date"
        
        onChange={evt => this.setState({ name: evt.target.value })}
        className={classes.textField}
        InputLabelProps={{
          shrink: true,
        }}
      />
     
      <FormControl  className={classes.textField}>
          <InputLabel shrink htmlFor="shift-label-placeholder">
            Shift
          </InputLabel>
          <Select
          required
            value={this.state.shift}
            onChange={evt => this.setState({ shift : evt.target.value })}
            input={<Input name="shift" id="shift-label-placeholder" />}
            displayEmpty
            
            className={classes.selectEmpty}
          >
            <MenuItem value="">
              <em>Select shift</em>
            </MenuItem>
            <MenuItem value={1}>Shift 1</MenuItem>
            <MenuItem value={2}>Shift 2</MenuItem>
            <MenuItem value={3}>Shift 3</MenuItem>
          </Select>
          <FormHelperText>*required</FormHelperText>
        </FormControl>
        {/* <button type="submit" >Submit</button> */}
       {/* <Button variant="contained" color="primary" className={classes.button}>
          Proceed
        </Button> */}
        </div>
       
        </CardContent>
        
         
       </form>
       {errors.map(error => (
          <p key={error}>Error: {error}</p>
        ))}
    </Paper>
 
    </div>
   

    </MuiThemeProvider > 
 

  );
}
  }

export default withStyles(styles)(Home);

