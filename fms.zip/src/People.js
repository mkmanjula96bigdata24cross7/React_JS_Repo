import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Headerbar from './components/Headerbar'
import MuiThemeProvider from '@material-ui/core/styles/MuiThemeProvider';
import TextField from '@material-ui/core/TextField';
import { createMuiTheme } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import CardHeader from '@material-ui/core/CardHeader';
import Checkbox from '@material-ui/core/Checkbox';
import Paper from '@material-ui/core/Paper';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';



const styles = theme =>( {
    avatar: {
        backgroundColor: 'black',
      },
      chead: {
        backgroundColor: '#FFC107',
        color: "black",
        fontSize :30,
        fontWeight:'bold'
        
      },
      subhead: {
        color: "#ECEFF1",
        backgroundColor: "#F5F5F5",
        fontSize :30,
        fontWeight:'bold'
        
      },
    card: {
        //minWidth: 275,
        height:300,
        marginLeft: theme.spacing.unit*3,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit*6,
        color: '#Ffab00'
      },
      paper: {
        //minWidth: 275,
        //height:300,
        marginLeft: theme.spacing.unit*6,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit*6,
        color: '#Ffab00'
      },
      textField: {
        marginLeft: theme.spacing.unit*6,
        marginTop: theme.spacing.unit*4,
    marginRight: theme.spacing.unit*6,
        width: 200,
      },
      heading: {
        fontSize: 14,
        fontWeight: 'bold',
        
       
      },

      text:{
        marginLeft: theme.spacing.unit*7,
        marginTop: theme.spacing.unit,
        fontSize: 14,
        fontWeight: 'bold',
        
      },
      container: {
        display: 'flex',
        flexWrap: 'wrap',
      },
     
  root: {
    flexGrow: 20,
    marginTop:1
  },
  grow: {
    flexGrow: 10,
    align:'center'
  },
  
 
  button: {
    // marginTop:10,
    // minWidth: 150,
    // marginLeft: 70,
    margin: theme.spacing.unit,
    backgroundColor:  'black',
    color:'white'
  },
 title:{
    fontSize:17,
    fontWeight:'bold'

 } ,
 containerexp: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textFieldexp: {
    marginLeft: theme.spacing.unit*5,
        marginTop: theme.spacing.unit,
    
  width: 150,
  fontSize:10
},
checked: {},
});

const theme1 = createMuiTheme({
    palette: {
        primary:{
            main: '#263238'
        },
      secondary: {
          main: '#FFC107'
                }
            },
    
                  
  
          });
          function validate(main_op,main_app,main_ag,rail_op,rail_app,rail_ag,feed_op,feed_app,feed_ag){
            const errors=[]
            if(main_op < 0 || main_ag<0 || main_app <0|| feed_op < 0 || feed_ag<0 || feed_app <0||rail_op < 0 || rail_ag<0 || rail_app <0){
              //alert.show('negative')
              errors.push("No of operators/apprentice/agency cannot be negative. Please enter positive number!!")
            }
            
            return errors;
          }


//function ButtonAppBar(props) {
 // const { classes } = props;
  //const bull = <span className={classes.bullet}>•</span>;
  class People extends React.Component{
    state = {
        age: '',
        name:'',
        main_op:'0',
        main_ag:'0',
        main_app:'0',
        rail_op:'0',
        rail_ag:'0',
        rail_app:'0',
        feed_op:'0',
        feed_ag:'0',
        feed_app:'0',
        checkedA: true,
        errors:[],
        labelWidth: 0,
      };
      constructor(props) {
        super(props);
        this.handlesubmit=this.handlesubmit.bind(this);
      }
    
      handleChange = name => event => {
        this.setState({
          [name]: event.target.value,
        });
      };
    
      handlesubmit(e){
        e.preventDefault();
        const {main_op} =this.state;
        const {main_app} =this.state;
        const {main_ag} =this.state;
        const {rail_op} =this.state;
        const {rail_app} =this.state;
        const {rail_ag} =this.state;
        
        const {feed_op} =this.state;
        const {feed_app} =this.state;
        const {feed_ag} =this.state;
        
        
        const errors = validate(main_op,main_app,main_ag,rail_op,rail_app,rail_ag,feed_op,feed_app,feed_ag);
        if(errors.length > 0){
          this.setState({errors});
          return;
        }
        else{
          let path = '/quality';
          this.props.history.push(path);
        }
        
      }
      // handleClick(e) {
      //   e.preventDefault();
      // }
      
      // handleChange = event => {
      //   this.setState({ [event.target.name]: event.target.value });
      // };
       handleCallToRouter = (value) => {
           this.props.history.push(value);
         } 


  render(){
    const { classes } = this.props;
    const { errors} = this.state;
  return (
    
    <MuiThemeProvider theme={theme1}> 

    <Headerbar> </Headerbar>
    
      <div>

      <Paper className={classes.paper}>
      <form name='peopleform' onSubmit={this.handlesubmit}   autoComplete="off">

      <CardHeader className={classes.chead} 
          avatar={
            <Avatar aria-label="Recipe" className={classes.avatar}>
              P
              
            </Avatar>
          }
          classes={{
            title: classes.title,
          }}
          title="People Information"
          action={
            <Button type='submit' variant="contained" color='secondary' className={classes.button}>
            Proceed
          </Button>
           }
        />
      <div className={classes.root}>

      <ExpansionPanel className={classes.subhead}  >
        <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
          <Typography className={classes.heading}>Main/ Body</Typography>
        </ExpansionPanelSummary>
        <div>
        <ExpansionPanelDetails>
        <div>
        <TextField
        required
        type='number'
        
        //name='main_op'
        value={this.state.main_op}
          onChange={this.handleChange('main_op')}
       
       // onChange={evt => this.setState({ shift : evt.target.value })}
        
       
        
          label="No of Operators"
          //defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        <TextField
         required
         value={this.state.main_app}
         onChange={this.handleChange('main_app')}
        type='number'
          id="outlined-uncontrolled"
          label="No. of Apprentice"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        <TextField
         required
         value={this.state.main_ag}
         onChange={this.handleChange('main_ag')}
        type='number'
        min='0'
          id="outlined-uncontrolled"
          label="No of Agency"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        </div>
        <br/>
        <div>
                  <Typography className={classes.text}>Is Injury free day?</Typography>
                
                  {/* <FormLabel component="legend" >Is Injury free day?</FormLabel> */}

        {/* <FormControlLabel label="Is Injury free day?"/> */}
                <FormControlLabel className={classes.textFieldexp} control={<Checkbox value="checkedA" />} label="Yes" />
                <FormControlLabel className={classes.textFieldexp} control={<Checkbox value="checkedC" />} label="No" />
                </div>
       
        </ExpansionPanelDetails>
        </div>
      </ExpansionPanel>
      <ExpansionPanel className={classes.subhead}  >
        <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
          <Typography className={classes.heading}>Feeder/ Rail</Typography>
        </ExpansionPanelSummary>
        <div>
        <ExpansionPanelDetails>
        <div>
        <TextField
         required
        type='number'
        value={this.state.feed_op}
        onChange={this.handleChange('feed_op')}
        pattern="[0-9]*"
          id="outlined-uncontrolled"
          label="No of Operators"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        <TextField
         required
        type='number'
        value={this.state.feed_app}
        onChange={this.handleChange('feed_app')}
          id="outlined-uncontrolled"
          label="No. of Apprentice"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        <TextField
         required
        type='number'
        value={this.state.feed_ag}
        onChange={this.handleChange('feed_ag')}
          id="outlined-uncontrolled"
          label="No of Agency"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        </div>
        <br/>
        <div>
                  <Typography className={classes.text}>Is Injury free day?</Typography>
                
                  {/* <FormLabel component="legend" >Is Injury free day?</FormLabel> */}

        {/* <FormControlLabel label="Is Injury free day?"/> */}
                <FormControlLabel className={classes.textFieldexp} control={<Checkbox value="checkedA" />} label="Yes" />
                <FormControlLabel className={classes.textFieldexp} control={<Checkbox value="checkedC" />} label="No" />
                </div>
       
        </ExpansionPanelDetails>
        </div>
      </ExpansionPanel>
      <ExpansionPanel className={classes.subhead}  >
        <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
          <Typography className={classes.heading}>BHL</Typography>
        </ExpansionPanelSummary>
        <div>
        <ExpansionPanelDetails>
        <div>
        <TextField
         required
        type='number'
        value={this.state.rail_op}
        onChange={this.handleChange('rail_op')}
          id="outlined-uncontrolled"
          label="No of Operators"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        <TextField
         required
        type='number'
        value={this.state.rail_app}
        onChange={this.handleChange('rail_app')}
          id="outlined-uncontrolled"
          label="No. of Apprentice"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        <TextField
         required
        type='number'
        value={this.state.rail_ag}
        onChange={this.handleChange('rail_ag')}
          id="outlined-uncontrolled"
          label="No of Agency"
          defaultValue='0'
          className={classes.textFieldexp}
          margin="normal"
          variant="outlined"
        />
        </div>
        <br/>
        <div>
                  <Typography className={classes.text}>Is Injury free day?</Typography>
                
                  {/* <FormLabel component="legend" >Is Injury free day?</FormLabel> */}

        {/* <FormControlLabel label="Is Injury free day?"/> */}
                <FormControlLabel className={classes.textFieldexp} control={<Checkbox value="checkedA" />} label="Yes" />
                <FormControlLabel className={classes.textFieldexp} control={<Checkbox value="checkedC" />} label="No" />
                </div>
       
        </ExpansionPanelDetails>
        </div>
      </ExpansionPanel>

       

    </div>
      
    </form>
    <div >
    {errors.map(error => (
          <p key={error}> {error}</p>
        ))}
        </div>
    </Paper>




    {/* <Button variant="contained" color="primary" className={classes.button}>
            Proceed
          </Button> */}
    </div>
   
    </MuiThemeProvider > 
 

  );
}
  }

export default withStyles(styles)(People);

