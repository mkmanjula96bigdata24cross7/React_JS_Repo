import React from "react";
import PropTypes from 'prop-types';
import Button from '@material-ui/core/Button';
import MuiThemeProvider from '@material-ui/core/styles/MuiThemeProvider';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import Paper from '@material-ui/core/Paper';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import CardHeader from '@material-ui/core/CardHeader';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import Divider from '@material-ui/core/Divider';
import Headerbar from './components/Headerbar'

const style1 = {
  
 
 marginTop:10,
  marginLeft: 850,
  marginRight: 'auto',

  fontFamily: 'sans-serif'
}
const style2 = {
  
 
  marginTop:10,
   marginLeft: 50,
  
  
   fontFamily: 'sans-serif'
 }
 
const styles = theme=>({
  
  card: {
    marginTop: 50,
    marginLeft:70,
    marginRight:70,
    
    
  },
  textField: {
    //   marginTop:50,
    // marginLeft: 90,
    // marginRight: 30,
    marginLeft: theme.spacing.unit*7,
    marginTop: theme.spacing.unit*4,
marginRight: theme.spacing.unit,
    width: 400,
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    display: 'flex',
    flexWrap: 'wrap',
  },
  table: {
    minWidth: 700,
  },
  
  margin1: {
    margin:  theme.spacing.unit,
    // marginTop: -80,
    // marginLeft:750,
  },
  paper: {
    //minWidth: 275,
    height:'flex',
    marginLeft: theme.spacing.unit*6,
    marginTop: theme.spacing.unit*4,
marginRight: theme.spacing.unit*6,
    color: '#Ffab00'
  },
  avatar: {
    backgroundColor: 'black',
  },
  chead: {
    backgroundColor: '#FFC107',
    color: "black",
    fontSize :30,
    fontWeight:'bold'
    
  },
  fab: {
    margin: theme.spacing.unit,
  },
  title:{
    fontSize:17,
    fontWeight:'bold'

 } ,
 textbox:{
  color: "black",
  width:200,
  height:20
 },
 button: {
  margin: theme.spacing.unit,
  // marginTop:10,
  // minWidth: 150,
  // marginLeft: 70,
  
  backgroundColor:  'black',
  color:'white'
},
addcon:{
  marginTop:10,
  minWidth: 150,
  marginLeft: 70,
}
});
//const imgMyimageexample = require('delivery.png');


const themes1 = createMuiTheme({
  palette: {
      primary:{
          main: '#263238'
      },
    secondary: {
        main: '#FFC107'
              }
          },
  
                

        });
        
        const textbx = {
         padding: "10px 20px ",
         margin : 6,
    
         border: "1px solid gray",
         borderRadius: 5,
          float: 'right'
  
       
 
        };
          
        const textbx1 = {
          padding: "10px 20px ",
          margin : 12,
         marginLeft:40,
          border: "1px solid gray",
          borderRadius: 5,
           float: 'right'
   
        
  
         };
      
        class QualityList extends React.Component {
          constructor(props) {
            super(props);
            this.routeChange = this.routeChange.bind(this)
            console.log(this.props )
            //  this.state.products = [];
            this.state = {};
            this.state.filterText = "";
            this.state.products = [];
          }

          routeChange() {
            let path = '/cost';
            this.props.history.push(path);
          }

          handleUserInput(filterText) {
            this.setState({ filterText: filterText });
          }
          handleRowDel(product) {
            var index = this.state.products.indexOf(product);
            this.state.products.splice(index, 1);
            this.setState(this.state.products);
          }
        
          handleAddEvent(evt) {
            var id = (+new Date() + Math.floor(Math.random() * 999999)).toString(36);
            var product = {
              id: id,
              name: "",
              price: "",
              // category: "",
              // qty: ""
            };
            this.state.products.push(product);
            this.setState(this.state.products);
          }
        
          handleProductTable(evt) {
            var item = {
              id: evt.target.id,
              name: evt.target.name,
              value: evt.target.value
            };
            var products = this.state.products.slice();
            var newProducts = products.map(function(product) {
              for (var key in product) {
                if (key == item.name && product.id == item.id) {
                  product[key] = item.value;
                }
              }
              return product;
            });
            this.setState({ products: newProducts });
            //  console.log(this.state.products);
          }
          render() {
            const classes  = this.props.classes;
            return (
              <div>
                <Headerbar></Headerbar>
               
                <Paper className={classes.paper}>
      <CardHeader className={classes.chead} 
          avatar={
            <Avatar aria-label="quality_label" className={classes.avatar}>
              Q
              
            </Avatar>
          }
          classes={{
            title: classes.title,
          }}
          title="Quality Details"
          
          action={
            <span>
           
          <span>
                <Button variant="contained"  onClick={this.routeChange}  color='primary' className={classes.button}>
            Proceed
          </Button>
          
            </span>
            </span>
          
           }
        />
              
              <span >
              <SearchBar
              class="pull-right"
            filterText={this.state.filterText}
            onUserInput={this.handleUserInput.bind(this)}
          ></SearchBar>
          </span>
          <Divider />
                <ProductTable
                  onProductTableUpdate={this.handleProductTable.bind(this)}
                  onRowAdd={this.handleAddEvent.bind(this)}
                  onRowDel={this.handleRowDel.bind(this)}
                  products={this.state.products}
                  filterText={this.state.filterText}
                />
                </Paper>
              </div>
            );
          }
        }
        class SearchBar extends React.Component {
          handleChange() {
            this.props.onUserInput(this.refs.filterTextInput.value);
          }
          render() {
            return (
             
                <input
                  type="text"
                  style={textbx}
                  placeholder="Search..."
                  value={this.props.filterText}
                  ref="filterTextInput"
                  onChange={this.handleChange.bind(this)}
                />
              
              
            );
          }
        }
        
        class ProductTable extends React.Component {
          render() {
            var onProductTableUpdate = this.props.onProductTableUpdate;
            var rowDel = this.props.onRowDel;
            var filterText = this.props.filterText;
            var product = this.props.products.map(function(product) {
              if (product.name.indexOf(filterText) === -1) {
                return;
              }
              return (
                <ProductRow
                  onProductTableUpdate={onProductTableUpdate}
                  product={product}
                  onDelEvent={rowDel.bind(this)}
                  key={product.id}
                />
              );
            });
            return (
              <div>
                {/* <Button
                variant='contained'
                  type="button"
                  onClick={this.props.onRowAdd}
                  className="btn btn-success pull-right"
                >
                  Add
                </Button> */}
               
               <div>
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th>
                      <MuiThemeProvider theme={themes1}> 

                <Fab size="small" color="secondary" aria-label="Add" onClick={this.props.onRowAdd} >
          <AddIcon />
        </Fab>
        </MuiThemeProvider>
                      </th>
                      {/* <th>Quality type</th>
                      <th>Defect Notes</th> */}
                      {/* <th>quantity</th>
                      <th>category</th> */}
                    </tr>
                  </thead>
        
                  <tbody>{product}</tbody>
                </table>
               </div>
              </div>
            );
          }
        }
        
        class ProductRow extends React.Component {
          onDelEvent() {
            this.props.onDelEvent(this.props.product);
          }
          render() {
            const { classes } = this.props;
            return (
          
        
              <MuiThemeProvider >
       
        
              <tr className="eachRow">
                <EditableCell
                  onProductTableUpdate={this.props.onProductTableUpdate}
                  cellData={{
                    type: "name",
                    value: this.props.product.name,
                    id: this.props.product.id
                  }}
                />
                <EditableCell
                  onProductTableUpdate={this.props.onProductTableUpdate}
                  cellData={{
                    type: "price",
                   
                    value: this.props.product.price,
                    id: this.props.product.id
                  }}
                />
                {/* <EditableCell
                  onProductTableUpdate={this.props.onProductTableUpdate}
                  cellData={{
                    type: "qty",
                    value: this.props.product.qty,
                    id: this.props.product.id
                  }}
                />
                <EditableCell
                  onProductTableUpdate={this.props.onProductTableUpdate}
                  cellData={{
                    type: "category",
                    value: this.props.product.category,
                    id: this.props.product.id
                  }}
                /> */}
                {/* <td>
                <Fab aria-label="Delete"
                 >
        <DeleteIcon />
      </Fab>
                </td> */}



                <td>
                <IconButton aria-label="Delete" >
          <DeleteIcon fontSize="medium"
           onClick={this.onDelEvent.bind(this)}
           value="X"
            />
        </IconButton>

                </td>
                {/* <td className="del-cell">
                  <input
                    type="button"
                    onClick={this.onDelEvent.bind(this)}
                    value="X"
                    className="del-btn"
                  />
                </td> */}
              </tr>
              </MuiThemeProvider>
            );
          }
        }

        class EditableCell extends React.Component {
       
          render() {
           
            return (
              
              <td >
                
                <input
                  type="text"
                  style={textbx1}
                 // className={this.props.classes.textField}
                  variant='outlined'
                  placeholder='Defect notes'
                  name={this.props.cellData.type}
                  id={this.props.cellData.id}
                  value={this.props.cellData.value}
                  onChange={this.props.onProductTableUpdate}
                />
              </td>
              
            
            );
          }
        }
    
        
        QualityList.propTypes = {
          classes: PropTypes.object.isRequired,
        };
export default withStyles(styles)(QualityList,EditableCell);


