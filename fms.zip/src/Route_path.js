import React, { Component } from 'react';
import App from './App';
import { Route, BrowserRouter as Router } from 'react-router-dom'
import Home from './Home';
import People from './People';
import Cost from './Cost'
import QualityList from './QualityList'
import snackalert from './components/snackalert'


class Route_path extends Component {

    render() {

        return (

            <Router><div>
                <Route exact path="/" component={App} /></div>
                
                <div >
                    <Route exact path="/home" component={Home} />
                </div>
                {/* <Route exact path="/" component={Headerbar} /> */}

                
                <div>
                    <Route exact path="/quality" component={QualityList} />

                </div>
                <Route exact path="/invaliduser" component={snackalert} />

                <Route exact path="/people" component={People} />
                <Route exact path="/cost" component={Cost} />
               
            </Router>

        );
    }
}

export default Route_path;