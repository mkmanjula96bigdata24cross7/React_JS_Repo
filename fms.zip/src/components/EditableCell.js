import React from 'react';
import TextField from '@material-ui/core/TextField';

class EditableCell extends React.Component {
       
    render() {
     
      return (
        
        <td >
          <TextField
            type="text"
           // className={this.props.classes.textField}
            variant='outlined'
            name={this.props.cellData.type}
            id={this.props.cellData.id}
            value={this.props.cellData.value}
            onChange={this.props.onProductTableUpdate}
          />
        </td>
        
      
      );
    }
  }
  export default EditableCell;