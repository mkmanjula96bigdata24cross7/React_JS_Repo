import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
//import Card from 'react-bootstrap/Card'
import {  Link } from "react-router-dom";
import MuiThemeProvider from '@material-ui/core/styles/MuiThemeProvider';
import { createMuiTheme } from '@material-ui/core/styles';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import LinkButton from '../LinkButton'


   
//import Route_path from './Route_path'
const styles = {
    avatar: {
        backgroundColor: 'black',
      },
      chead: {
        backgroundColor: '#FFC107',
        color: "black",
        fontSize :30,
        fontWeight:'bold'
        
      },
    card: {
        minWidth: 275,
        height:350,
        marginTop: 50,
        marginLeft:70,
        marginRight:70,
        color: '#Ffab00'
      },
      textField: {
          marginTop:70,
        marginLeft: 70,
        marginRight: 30,
        width: 200,
      },
  root: {
    flexGrow: 20,
    marginTop:1,
   
    
  },
  grow: {
    flexGrow: 10,
    align:'center'
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  formControl: {
   marginTop:-48,
    minWidth: 200,
    marginLeft: 400
    
  },

  
  button: {
    marginTop:30,
    minWidth: 150,
    marginLeft: 70,
    backgroundColor:  '#607D8B'
  },
 title:{
    fontSize:17,
    fontWeight:'bold'

 } 
};
//const imgMyimageexample = require('delivery.png');


const theme = createMuiTheme({
    palette: {
        primary:{
            main: '#263238'
        },
      secondary: {
          main: '#FFC107'
                }
            },
    
                  
  
          });


  class Headerbar extends React.Component{
    
      handleChange = event => {
        this.setState({ [event.target.name]: event.target.value });
      };
       handleCallToRouter = (value) => {
           this.props.history.push(value);
         } 
        state = {
            age: '',
            name: 'xyz',
            labelWidth: 0,
          };

  render(){
    const { classes } = this.props;
  return (
    
    <MuiThemeProvider theme={theme}> 
    <div className={classes.root}>
    
    <AppBar position="static" color="secondary">
    
      <Toolbar>
        <IconButton className={classes.menuButton} color="inherit" aria-label="Menu">
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" color="inherit"  className={classes.grow} >
          Facility Monitoring System
        </Typography>
        {/* <Link to="/" style={{ textDecoration: 'none',color:'primary',display: 'block', height: '100%'  }}><Button color="inherit" display='block' >Logout</Button></Link> */}
      
        <LinkButton style={{ textDecoration: 'none',color:'primary',display: 'block', height: '100%'  }}
  to='/'
  onClick={(event) => {
    console.log('custom event here!', event)
  }}
>Logout</LinkButton>
      
      </Toolbar>
      

    </AppBar>
    
    
      <AppBar position="static">
      <Tabs
         value={this.state.value}
         onChange={this.handleChange}
          indicatorColor="primary"
         
          
        >
        <Tab label="Home" value="/home" component={Link} to="/home"/>
          {/*  <Tab label="People" value="/people" component={Link} to="/people" />  */}
          {/* <Tab label="Home" />
          <Tab   label="People"   /> 
          <Tab label="Cost" /> */}
          <Tab label="People" value="/people" component={Link} to="/people" /> 
          <Tab label="Quality" value="/quality" component={Link} to="/quality" /> 

          <Tab label="Cost" value="/cost" component={Link} to="/cost"/>
          <Tab label="Report" value="#" component={Link} to="#"/>

        </Tabs>
       {/* <Tab label="Item Two" value="/login" component={Link} to="/login" />  */}

      </AppBar>
      
    </div>
      
   
    </MuiThemeProvider > 
 

  );
}
  }

export default withStyles(styles)(Headerbar);

