import React from 'react';
import IconButton from '@material-ui/core/IconButton';

import TextField from '@material-ui/core/TextField';
import { createMuiTheme } from '@material-ui/core/styles';
import MuiThemeProvider from '@material-ui/core/styles/MuiThemeProvider';
//import EditableCell from './components/EditableCell'
import DeleteIcon from '@material-ui/icons/Delete';
import CardHeader from '@material-ui/core/CardHeader';
import AddIcon from '@material-ui/icons/Add';
class ProductRow extends React.Component {
    onDelEvent() {
      this.props.onDelEvent(this.props.product);
    }
    render() {
      const { classes } = this.props;
      return (
    
  
        <MuiThemeProvider >
 
  
        <tr className="eachRow">
          <EditableCell
            onProductTableUpdate={this.props.onProductTableUpdate}
            cellData={{
              type: "name",
              value: this.props.product.name,
              id: this.props.product.id
            }}
          />
          <EditableCell
            onProductTableUpdate={this.props.onProductTableUpdate}
            cellData={{
              type: "price",
              value: this.props.product.price,
              id: this.props.product.id
            }}
          />
          {/* <EditableCell
            onProductTableUpdate={this.props.onProductTableUpdate}
            cellData={{
              type: "qty",
              value: this.props.product.qty,
              id: this.props.product.id
            }}
          />
          <EditableCell
            onProductTableUpdate={this.props.onProductTableUpdate}
            cellData={{
              type: "category",
              value: this.props.product.category,
              id: this.props.product.id
            }}
          /> */}
          {/* <td>
          <Fab aria-label="Delete"
           >
  <DeleteIcon />
</Fab>
          </td> */}



          <td>
          <IconButton aria-label="Delete" >
    <DeleteIcon fontSize="medium"
     onClick={this.onDelEvent.bind(this)}
     value="X"
      />
  </IconButton>

          </td>
          {/* <td className="del-cell">
            <input
              type="button"
              onClick={this.onDelEvent.bind(this)}
              value="X"
              className="del-btn"
            />
          </td> */}
        </tr>
        </MuiThemeProvider>
      );
    }
  }
  class EditableCell extends React.Component {
       
    render() {
     
      return (
        
        <td >
          <TextField
            type="text"
           // className={this.props.classes.textField}
            variant='outlined'
            name={this.props.cellData.type}
            id={this.props.cellData.id}
            value={this.props.cellData.value}
            onChange={this.props.onProductTableUpdate}
          />
        </td>
        
      
      );
    }
  }
  
 
export default ProductRow;